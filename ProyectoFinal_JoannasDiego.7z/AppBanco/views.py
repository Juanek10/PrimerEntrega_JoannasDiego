from django.http import HttpResponse
from django.shortcuts import render
from .models import *
from AppBanco.forms import *

# Create your views here.

def inicio(request):
    return render(request,"AppBanco/inicio.html")

def clientes(request):

    if request.method == 'POST':
        formulario=ClienteForm(request.POST)
        if formulario.is_valid():
            informacion=formulario.cleaned_data
            cliente = Clientes(codigo_cliente=informacion['codigo_cliente'], nombre=informacion['nombre'], email=informacion['email'])
            cliente.save()
            return render(request,"AppBanco/inicio.html")
    else:
        formulario=ClienteForm()
        return render(request,"AppBanco/clientes.html",{'formulario':formulario})

def buscar_cliente(request):
    return render(request,"AppBanco/busquedaCliente.html")

def buscar(request):
    if request.GET['codigo_cliente']:
        codigo_cliente=request.GET['codigo_cliente']
        cliente=Clientes.objects.filter(codigo_cliente=codigo_cliente)
        return render(request,"AppBanco/resultadoCliente.html",{'clientes':cliente})    
    else:
        respuesta="No se ingresó ningún código de cliente a buscar"
        return render(request,"AppBanco/resultadoCliente.html",{'respuesta':respuesta})
    
      
def productos(request):
    if request.method == 'POST':
        formulario=ProductoForm(request.POST)
        if formulario.is_valid():
            informacion=formulario.cleaned_data
            cliente = Productos(codigo_producto=informacion['codigo_producto'], descripcion=informacion['descripcion'], subproducto=informacion['subproducto'])
            cliente.save()
            return render(request,"AppBanco/inicio.html")
    else:
        formulario=ProductoForm()
        return render(request,"AppBanco/productos.html",{'formulario':formulario})

def sucursales(request):
    if request.method == 'POST':
        formulario=SucursalForm(request.POST)
        if formulario.is_valid():
            informacion=formulario.cleaned_data
            cliente = Sucursales(codigo_sucursal=informacion['codigo_sucursal'], sucursal=informacion['sucursal'], region=informacion['region'])
            cliente.save()
            return render(request,"AppBanco/inicio.html")
    else:
        formulario=SucursalForm()
        return render(request,"AppBanco/sucursales.html",{'formulario':formulario})