from django import forms

class ClienteForm(forms.Form):
    codigo_cliente=forms.IntegerField()
    nombre=forms.CharField(max_length=40)
    email=forms.EmailField()

class ProductoForm(forms.Form):
    codigo_producto=forms.IntegerField()
    descripcion=forms.CharField(max_length=40)
    subproducto=forms.CharField(max_length=40)

class SucursalForm(forms.Form):
    codigo_sucursal=forms.IntegerField()
    sucursal=forms.CharField(max_length=40)
    region=forms.CharField(max_length=20)